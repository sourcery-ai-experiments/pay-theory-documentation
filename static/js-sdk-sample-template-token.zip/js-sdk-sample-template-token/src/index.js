import { useQuery, gql } from '@apollo/client'; // Import the useQuery hook and gql tag function


const API_KEY = 'API_KEY'; 
const AMOUNT = 100;

const PAYOR_INFO =
    {
        first_name: "Jame",
        last_name: "Jon",
        phone: "3335554444",
        personal_address: {
            city: "Cincinnati",
            state: "OH",
            country: "USA",
            postal_Code: "41220"
        }
    };
    const BILLING_INFO = {
        name: "Some Body",
        address: {
            line1: "123 Street St",
            postal_code: "12345",
            country: "USA"
        }
    };
    const TOKEN_METADATA = {
      "system_id": "123456789"
    };
    const TOKENIZE_PAYMENT_METHOD_PARAMETERS = {
      payorInfo: PAYOR_INFO, // optional
      billingInfo: BILLING_INFO, // optional
      metadata: TOKEN_METADATA, // optional
    };



paytheory.errorObserver(e => console.log(e, "error"));
paytheory.stateObserver(e => console.log(e, "state"))
paytheory.validObserver(e => console.log(e, "valid"))

paytheory.payTheoryFields({
    apiKey: API_KEY
});

const paymentButton = document.getElementById('initiate-payment');
paymentButton.addEventListener('click', (e) => {
    e.preventDefault();
    paytheory.tokenizePaymentMethod(TOKENIZE_PAYMENT_METHOD_PARAMETERS)
             .then(result =>{
                const statusContainer = document.getElementById('result-text');
                if (result.type === "TOKENIZED") {
                    statusContainer.innerHTML = JSON.stringify(result.body);
                } else if (result.type === "ERROR") {
                    statusContainer.innerHTML = `Payment Error: ${result.error}`
                }
             }).catch(e => {
                const statusContainer = document.getElementById('result-text');
                statusContainer.innerHTML = JSON.stringify(e);
             });
});