# Pay Theory Javascript SDK: GUIDE_NAME

This repository contains a basic implementation of the Pay Theory SDK to demonstrate how to GUIDE_DESCRIPTION.

## Getting Started

You need to replace `API_KEY` with your API key in the `index.js` file.

You need to replace `IMPORT_SCRIPT` with your import script in the `index.html` file.

After you have done serve the `index.html` file with your favorite web server.