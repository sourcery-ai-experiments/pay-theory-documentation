import React, { useEffect, useState } from 'react';

export default function Payments()
{
    const [isSubmitDisabled, setIsSubmitDisabled] = useState(true);
    const [message, setMessage] = useState('');
    const [ptSdk,setPtSdk] = useState();

    const [cardNumberColor, setCardNumberColor] = useState('');
    const AMOUNT = 1000;
    const PAYOR_INFO =
    {
        first_name: "Nithya",
        last_name: "Indla",
        email: "nithya@gmail.com",
        phone: "3335554444",
        personal_address: {
            city: "Cincinnati",
            state: "OH",
            country: "USA",
            postal_Code: "45220"
        }
    };
    const FEE_MODE = window.paytheory.MERCHANT_FEE
    const PAYMENT_METADATA = {
        pay_theory_account_code: "code-123456789",
        pay_theory_reference: "field-trip"
    };
    const REQUIRE_CONFIRMATION = false

    const TRANSACTING_PARAMETERS = {
        amount: AMOUNT,
        payorInfo: PAYOR_INFO,
        fee: 100,
        confirmation: REQUIRE_CONFIRMATION,
        metadata: PAYMENT_METADATA,
        sendReceipt: true,
        receiptDescription: "School Fees",
    };
    const customPlaceholders = {
        cardNumber: "Card Number",
        cardCvv: "CVV",
        cardExp: "MM/YY"
    };
    useEffect(()=>{
        const runTransaction = async () => {
                const API_KEY = 'austin-paytheorylab-d7dbe665f5565fe8ae8a23eab45dd285';
                try{
                       paytheory.readyObserver(ready=>{
                        setIsSubmitDisabled(!ready);
                       });

                       paytheory.validObserver((valid) => {
                            console.log(valid)
                            const cardNumberInput = document.getElementById('pay-theory-credit-card');
                            console.log(cardNumberInput);
                            if (valid.cardNumber) {
                                setCardNumberColor('green');
                              } else {
                                setCardNumberColor('red');
                              }
                       });
                       paytheory.stateObserver(state=> {
                            if(!state.isFocused)
                            {
                                console.log("Field blurred")
                            }
                       });
                       paytheory.payTheoryFields({
                         apiKey: API_KEY

                       });



                }
                catch(error){
                    paytheory.errorObserver(error => {
                                 // Logic to respond to errors
                    });
                }

            };

        runTransaction();
    },[]);

     const handleSubmit = async (event) => {
          event.preventDefault();

          console.log("transact")
          const result = await paytheory.transact(TRANSACTING_PARAMETERS)


          if (result.type === "SUCCESS") {
          const { last_four } = result.body;
          console.log(last_four);
          setMessage('Payment Successful with card number ending in ' +' ' + last_four);
          } else if (result.type === "FAILURE") {

          setMessage("Payment Failed");
          } else if (result.type === "ERROR") {

          setMessage("Payment error");
          }
     };

     return (
        <form>

           {/* Your other form fields */}
           <div id="pay-theory-credit-card" ></div>
           <div id="pay-theory-credit-card-zip"></div>
           <div>
                <button
                type = "submit"
                id="submit"
                onClick={handleSubmit}
                >
                Submit
                </button>
           </div>
           {message && <p>{message}</p>}
         </form>
       );

};


