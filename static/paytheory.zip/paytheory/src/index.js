import React, { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

import Paytheory from "./Paytheory";
//import Someone from "./Someone";
const root = createRoot(document.getElementById("root"));
root.render(
//  <StrictMode>
    <Paytheory />
//  </StrictMode>
);